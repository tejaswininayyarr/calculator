const board = document.getElementById('board');
const statusText = document.getElementById('status');
const resetBtn = document.getElementById('reset');

let cells = [];
let currentPlayer = 'X';
let gameActive = true;

const winPatterns = [
  [0,1,2], [3,4,5], [6,7,8],
  [0,3,6], [1,4,7], [2,5,8],
  [0,4,8], [2,4,6]
];

function createBoard() {
  board.innerHTML = '';
  cells = [];
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.index = i;
    cell.addEventListener('click', handlePlayerMove);
    board.appendChild(cell);
    cells.push(cell);
  }
  currentPlayer = 'X';
  statusText.textContent = "Agent X, your move...";
  gameActive = true;
}

function handlePlayerMove(e) {
  const cell = e.target;
  const index = cell.dataset.index;

  if (!gameActive || cell.textContent !== '') return;

  makeMove(index, 'X');

  if (checkWinner('X')) {
    statusText.textContent = "🎉 Agent X wins the mission!";
    gameActive = false;
    return;
  }

  if (isDraw()) {
    statusText.textContent = "It's a stalemate. Mission neutralized.";
    gameActive = false;
    return;
  }

  statusText.textContent = "Agent O (computer) is thinking...";
  setTimeout(computerMove, 600); // Delay for realism
}

function makeMove(index, player) {
  cells[index].textContent = player;
}

function computerMove() {
  if (!gameActive) return;

  let emptyCells = cells
    .map((cell, idx) => cell.textContent === '' ? idx : null)
    .filter(idx => idx !== null);

  if (emptyCells.length === 0) return;

  let randomIndex = emptyCells[Math.floor(Math.random() * emptyCells.length)];
  makeMove(randomIndex, 'O');

  if (checkWinner('O')) {
    statusText.textContent = "💥 Agent O (computer) wins!";
    gameActive = false;
    return;
  }

  if (isDraw()) {
    statusText.textContent = "It's a stalemate. Mission neutralized.";
    gameActive = false;
    return;
  }

  statusText.textContent = "Agent X, your move...";
}

function checkWinner(player) {
  return winPatterns.some(pattern =>
    pattern.every(index => cells[index].textContent === player)
  );
}

function isDraw() {
  return cells.every(cell => cell.textContent !== '');
}

resetBtn.addEventListener('click', createBoard);

createBoard();
